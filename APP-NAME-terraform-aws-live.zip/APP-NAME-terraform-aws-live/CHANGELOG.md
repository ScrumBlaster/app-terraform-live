# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## 3.16.0 (2020-08-25)


### Style

* Rename Karlsruhe --> Stuttgart ([a44444d](http://gitlab.common.internal/.......<LINK HERE>......./-/commit/a44444d21e25b68520f6a34e0d575233ea19b408))
